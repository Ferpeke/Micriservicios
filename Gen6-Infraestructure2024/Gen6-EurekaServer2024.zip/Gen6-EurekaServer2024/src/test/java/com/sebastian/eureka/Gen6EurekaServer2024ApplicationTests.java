package com.sebastian.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gen6EurekaServer2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
